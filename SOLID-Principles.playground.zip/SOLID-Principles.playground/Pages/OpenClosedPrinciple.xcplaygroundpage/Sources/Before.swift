import Foundation

fileprivate class PaymentManager {
    
    func makeCashPayment(amount: Double) {
        // perform payment with cash
    }
    
    func makeVisaPayment(amount: Double) {
        // perform payment with Visa
    }
    
    func makeMasterCardPayment(amount: Double) {
        // perform payment with Master Card
    }
}
